# Sample Template 1

This is a sample chatmode template for {AI_ASSISTANT}.

## Usage

Use {AI_SHORTNAME} to activate this mode with: {AI_COMMAND}

## Instructions

1. Analyze the current project structure
2. Provide recommendations
3. Generate code following best practices

## Keywords for {AI_SHORTNAME}

- Project analysis
- Code generation
- Best practices
