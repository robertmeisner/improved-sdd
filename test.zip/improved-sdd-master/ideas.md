- modify chatmode: rename feasibility.md to 01_feasibility.md requirements.md to 02_requirements.md and design.md to 03_design.md tasks.md to 04_tasks.md
rename feasibility.md and tasks.md to 04_tasks.md

- modify chatmode: introduce Gitlab Flow to spec chatmode. Make a new feature branch BEFORE you create a new spec files. they have to be created inside branch. After you finish the spec tasks, ask user and only then create a PR to main. new spec file ALWAYS have to be developed in a feature branch. Never work on main branch directly.
